import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Quote } from "lucide-react"

export function TestimonialsSection() {
  return (
    <section className="py-24 sm:py-32 bg-gray-50">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Farmers Love AquaguardAI
          </h2>
        </div>
        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24">
          <div className="relative rounded-2xl bg-white p-8 shadow-xl">
            <Quote className="absolute -top-4 left-4 h-8 w-8 text-green-600" />
            <blockquote className="text-lg font-semibold leading-8 text-gray-900">
              &ldquo;They said they love AquaGuard AI and never want to go back to &apos;just hoping for the best&apos; again.&rdquo;
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  )
} 