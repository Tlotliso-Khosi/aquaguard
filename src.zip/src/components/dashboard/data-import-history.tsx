"use client"

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, CheckCircle2, XCircle } from "lucide-react"

const importHistory = [
  {
    id: 1,
    date: "2024-03-15",
    fileName: "yield_data_2024_03.csv",
    records: 150,
    status: "success",
    size: "2.5 MB",
  },
  {
    id: 2,
    date: "2024-03-14",
    fileName: "soil_data_2024_03.csv",
    records: 200,
    status: "success",
    size: "3.1 MB",
  },
  {
    id: 3,
    date: "2024-03-13",
    fileName: "weather_data_2024_03.csv",
    records: 180,
    status: "error",
    size: "1.8 MB",
  },
]

export function DataImportHistory() {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Import History</h3>
        <Button>
          <Download className="mr-2 h-4 w-4" />
          Download History
        </Button>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Date</TableHead>
            <TableHead>File Name</TableHead>
            <TableHead>Records</TableHead>
            <TableHead>Size</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {importHistory.map((import_) => (
            <TableRow key={import_.id}>
              <TableCell>{import_.date}</TableCell>
              <TableCell className="font-medium">{import_.fileName}</TableCell>
              <TableCell>{import_.records}</TableCell>
              <TableCell>{import_.size}</TableCell>
              <TableCell>
                <Badge
                  variant={import_.status === "success" ? "default" : "destructive"}
                >
                  {import_.status === "success" ? (
                    <CheckCircle2 className="mr-1 h-3 w-3" />
                  ) : (
                    <XCircle className="mr-1 h-3 w-3" />
                  )}
                  {import_.status}
                </Badge>
              </TableCell>
              <TableCell>
                <Button variant="ghost" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
} 