"use client"

import { Progress } from "@/components/ui/progress"
import { Card, CardContent } from "@/components/ui/card"

const metrics = [
  {
    name: "Data Completeness",
    value: 98.5,
    description: "Percentage of required fields filled",
  },
  {
    name: "Data Accuracy",
    value: 97.2,
    description: "Percentage of data validated against rules",
  },
  {
    name: "Data Consistency",
    value: 99.1,
    description: "Percentage of data following defined patterns",
  },
  {
    name: "Data Timeliness",
    value: 95.8,
    description: "Percentage of data updated within 24h",
  },
]

export function DataQualityMetrics() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      {metrics.map((metric) => (
        <Card key={metric.name}>
          <CardContent className="pt-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">{metric.name}</p>
                <p className="text-sm font-medium">{metric.value}%</p>
              </div>
              <Progress value={metric.value} className="h-2" />
              <p className="text-xs text-muted-foreground">
                {metric.description}
              </p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
} 