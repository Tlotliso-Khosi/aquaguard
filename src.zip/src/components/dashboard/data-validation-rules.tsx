"use client"

import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Plus } from "lucide-react"

const validationRules = [
  {
    id: 1,
    name: "Required Fields",
    description: "Ensure all mandatory fields are filled",
    enabled: true,
  },
  {
    id: 2,
    name: "Data Format",
    description: "Validate data format and structure",
    enabled: true,
  },
  {
    id: 3,
    name: "Value Range",
    description: "Check if values are within acceptable ranges",
    enabled: false,
  },
  {
    id: 4,
    name: "Data Consistency",
    description: "Ensure data consistency across related fields",
    enabled: true,
  },
]

export function DataValidationRules() {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Validation Rules</h3>
        <Button size="sm">
          <Plus className="mr-2 h-4 w-4" />
          Add Rule
        </Button>
      </div>

      <div className="space-y-4">
        {validationRules.map((rule) => (
          <div
            key={rule.id}
            className="flex items-center justify-between p-4 border rounded-lg"
          >
            <div className="space-y-1">
              <Label className="text-sm font-medium">{rule.name}</Label>
              <p className="text-sm text-muted-foreground">
                {rule.description}
              </p>
            </div>
            <Switch defaultChecked={rule.enabled} />
          </div>
        ))}
      </div>
    </div>
  )
} 