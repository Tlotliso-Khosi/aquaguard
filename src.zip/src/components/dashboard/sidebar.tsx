"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { useTranslation } from "react-i18next";
import {
  LayoutDashboardIcon,
  CloudSunIcon,
  UsersIcon,
  DatabaseIcon,
  FileTextIcon,
  StoreIcon,
  MapIcon,
  LogOutIcon,
  LayoutIcon,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import Image from "next/image";
import { Button } from "@/components/ui/button";

interface SidebarItemProps {
  path: string;
  icon: LucideIcon;
  labelKey: string;
}

function SidebarItem({ path, icon: Icon, labelKey }: SidebarItemProps) {
  const pathname = usePathname();
  const isActive = pathname === path;
  const { t } = useTranslation();

  return (
    <Link
      href={path}
      className={cn(
        "flex items-center gap-3 rounded-lg px-4 py-2 text-sm transition-all hover:bg-slate-100/80",
        isActive ? "bg-secondary text-white hover:bg-secondary" : "text-slate-500"
      )}
    >
      <Icon className={cn("h-[18px] w-[18px]", isActive ? "text-white" : "text-slate-500")} />
      {t(labelKey)}
    </Link>
  );
}

export default function Sidebar() {
  const { t } = useTranslation();
  
  const handleLogout = () => {
    // Implement logout logic here
    console.log("Logging out...");
  };

  return (
    <div className="fixed left-4 top-4 flex h-[calc(100vh-32px)] w-[250px] flex-col rounded-xl border border-slate-200 bg-white p-4 shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
      <div className="flex items-center gap-2 px-2 pb-6 border-b border-slate-100">
        <Image src="/logo-dark.svg" alt="AquaGuard AI" width={32} height={32} />
        <span className="text-base font-semibold text-slate-900">AquaGuard AI</span>
      </div>
      
      <nav className="flex flex-1 flex-col gap-1 pt-6">
        <SidebarItem path="/dashboard" icon={LayoutDashboardIcon} labelKey="sidebar.dashboard" />
        <SidebarItem path="/dashboard/field-management" icon={LayoutIcon} labelKey="sidebar.fieldManagement" />
        <SidebarItem path="/dashboard/weather" icon={CloudSunIcon} labelKey="sidebar.weather" />
        <SidebarItem path="/dashboard/data-management" icon={DatabaseIcon} labelKey="sidebar.dataManagement" />

        <SidebarItem path="/dashboard/reports" icon={FileTextIcon} labelKey="sidebar.reports" />
        <SidebarItem path="/dashboard/community" icon={UsersIcon} labelKey="sidebar.community" />
        <SidebarItem path="/dashboard/market" icon={StoreIcon} labelKey="sidebar.market" />
        <SidebarItem path="/dashboard/map" icon={MapIcon} labelKey="sidebar.map" />
      </nav>
      
      <div className="mt-auto pt-6 border-t border-slate-100">
        <Button 
          variant="ghost" 
          className="w-full flex items-center justify-start gap-3 text-sm text-slate-500 bg-slate-100/80 hover:bg-slate-100/60 hover:text-slate-700"
          onClick={handleLogout}
        >
          <LogOutIcon className="h-[18px] w-[18px] text-slate-500" />
          {t("sidebar.logout") || "Logout"}
        </Button>
      </div>
    </div>
  );
}
