"use client";

import * as React from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Plus, Search, Users, MessageSquare, Star, MoreVertical } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import Image from "next/image";
interface ForumPost {
  id: string;
  title: string;
  content: string;
  author: {
    name: string;
    avatar: string;
    role: string;
  };
  timestamp: string;
  likes: number;
  comments: number;
}

interface Group {
  id: string;
  name: string;
  description: string;
  members: number;
  topics: string[];
  image: string;
}

export default function CommunityPage() {
  const { t } = useTranslation();

  // Mock data - replace with actual data from your backend
  const forums: ForumPost[] = [
    {
      id: "1",
      title: "Best practices for water conservation",
      content: "I've been implementing drip irrigation and would like to share my experience...",
      author: {
        name: "John Smith",
        avatar: "/avatars/john.jpg",
        role: "Farmer",
      },
      timestamp: "2 hours ago",
      likes: 24,
      comments: 8,
    },
    {
      id: "2",
      title: "New pest control methods",
      content: "Has anyone tried the new organic pest control solution?",
      author: {
        name: "Sarah Johnson",
        avatar: "/avatars/sarah.jpg",
        role: "Agricultural Expert",
      },
      timestamp: "5 hours ago",
      likes: 18,
      comments: 12,
    },
  ];

  const groups: Group[] = [
    {
      id: "1",
      name: "Organic Farming Community",
      description: "Share experiences and tips about organic farming methods",
      members: 156,
      topics: ["Organic", "Sustainable", "Certification"],
      image: "/groups/organic.jpg",
    },
    {
      id: "2",
      name: "Smart Irrigation Group",
      description: "Discussion about modern irrigation techniques and technologies",
      members: 89,
      topics: ["Irrigation", "Technology", "Water Management"],
      image: "/groups/irrigation.jpg",
    },
  ];

  return (
    <div className="container mx-auto p-6">
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-900">{t('community.title')}</h2>
        <Button className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          {t('community.createNew')}
        </Button>
      </div>

      <Tabs defaultValue="forums" className="space-y-4">
        <TabsList>
          <TabsTrigger value="forums">{t('community.tabs.forums')}</TabsTrigger>
          <TabsTrigger value="groups">{t('community.tabs.groups')}</TabsTrigger>
        </TabsList>

        <TabsContent value="forums" className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input
                placeholder={t('community.search.forums')}
                className="pl-10"
              />
            </div>
            <Button variant="outline">{t('community.filter')}</Button>
          </div>

          <div className="grid gap-4">
            {forums.map((forum) => (
              <Card key={forum.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <Avatar>
                        <AvatarImage src={forum.author.avatar} alt={forum.author.name} />
                        <AvatarFallback>{forum.author.name[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold text-slate-900">{forum.title}</h3>
                        <p className="text-sm text-slate-500">
                          {t('community.forum.postedBy', { name: forum.author.name })} • {forum.timestamp}
                        </p>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>{t('community.forum.report')}</DropdownMenuItem>
                        <DropdownMenuItem>{t('community.forum.share')}</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  <p className="mt-4 text-slate-600">{forum.content}</p>
                  <div className="mt-4 flex items-center gap-4">
                    <Button variant="ghost" size="sm" className="gap-2">
                      <Star className="h-4 w-4" />
                      {t('community.forum.likes', { count: forum.likes })}
                    </Button>
                    <Button variant="ghost" size="sm" className="gap-2">
                      <MessageSquare className="h-4 w-4" />
                      {t('community.forum.comments', { count: forum.comments })}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="groups" className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input
                placeholder={t('community.search.groups')}
                className="pl-10"
              />
            </div>
            <Button variant="outline">{t('community.filter')}</Button>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {groups.map((group) => (
              <Card key={group.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <div className="relative h-12 w-12 overflow-hidden rounded-lg">
                      <Image
                        src={group.image}
                        alt={group.name}
                        className="h-full w-full object-cover"
                        width={100}
                        height={100}
                      />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{group.name}</CardTitle>
                      <p className="text-sm text-slate-500">{group.description}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {group.topics.map((topic) => (
                      <span
                        key={topic}
                        className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600"
                      >
                        {topic}
                      </span>
                    ))}
                  </div>
                  <div className="mt-4 flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-slate-500">
                      <Users className="h-4 w-4" />
                      {t('community.group.members', { count: group.members })}
                    </div>
                    <Button variant="outline" size="sm">
                      {t('community.group.joinGroup')}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
} 