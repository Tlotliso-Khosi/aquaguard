from django.contrib.auth.backends import ModelBackend
from api.models import Customer

class EmailBackend(ModelBackend):
    def authenticate(self, request, email = None, password = None, **kwargs):
        if email is None or password is None:
            return None
        
        try:
            customer=Customer.objects.get(email=email)
            if customer.check_password(password):
                return customer
        except Customer.DoesNotExist:
            return None
        return None
