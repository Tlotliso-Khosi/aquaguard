from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CustomerViewSet, CustomerLoginView

urlpatterns =[
    path("register/", CustomerViewSet.as_view({"post":"create"}), name="customer-register"),
    path("login/", CustomerLoginView.as_view(), name="Customer-Login"),
]
