from django.shortcuts import render
from django.contrib.auth.models import User
from rest_framework import generics, viewsets, status
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from .serializers import CustomerSerializer
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.views import APIView
from .models import Customer
from django.db import IntegrityError
from rest_framework.permissions import AllowAny

class CustomerViewSet(viewsets.ModelViewSet):
    queryset= Customer.objects.all()
    serializer_class= CustomerSerializer

    def get_permissions(self):
        if self.action == 'create':
            return [AllowAny()]
        return super().get_permissions()

    def create(self, request, *arg, **kwargs):
        data= request.data.copy()
        print("Raw input data:", data)

        required_fields=["firstname","lastname","email","usertype"]

        #validate serializer
        serializer= self.get_serializer(data=data)
        if not serializer.is_valid():
            print("Serializer error", serializer.errors)
            return Response(
                {"detail": "Invalid data provided", "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            #create user - password will be hashed by create_user()

            customer= Customer.objects.create_user(
                email= data["email"].lower().strip(),
                firstname=data["firstname"],
                lastname=data["lastname"],
                usertype = data["usertype"],
                password=data["password"]
            )

            #debug: verify password was hashed
            print(f"Password  hash stored: {customer.password[:50]}...")

            refresh= RefreshToken.for_user(customer)
            return Response(
                {
                    "status": "success",
                    "customer": serializer.data,
                    "tokens": {
                        "refresh": str(refresh),
                        "access": str(refresh.access_token),
                    }
                },
                status=status.HTTP_201_CREATED
            )
        

        except IntegrityError as e:
            error_detail= "Email already exists" if "email" in str(e) else "ID number already exists"
            return Response(
                {"detail": error_detail},
                status=status.HTTP_400_BAD_REQUEST
            )
        
class CustomerLoginView(APIView):
    permission_classes = [AllowAny]
    
    def post(self, request, *args, **kwargs):
        email = request.data.get('email', '').lower().strip()
        password = request.data.get('password', '').strip()
        
        print(f"\nLogin attempt for: {email}")
        
        try:
            user = Customer.objects.get(email=email)
            print(f"User found. Password check: {user.check_password(password)}")
            print(f"Stored password hash: {user.password[:50]}...")
            
            # Manual authentication fallback
            if user.check_password(password):
                refresh = RefreshToken.for_user(user)
                return Response({
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                    'borrower': CustomerSerializer(user).data
                })
                
        except Customer.DoesNotExist:
            print("User not found in database")
        
        return Response(
            {'detail': 'Invalid email or password'},
            status=status.HTTP_401_UNAUTHORIZED
        )

