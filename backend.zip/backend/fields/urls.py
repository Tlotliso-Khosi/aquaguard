from django.urls import path, include
from .views import FieldCreateView

urlpatterns =[
    path("field-management/", FieldCreateView.as_view(), name="field-register"),
]
