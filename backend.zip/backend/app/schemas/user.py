from pydantic import BaseModel, EmailStr, Field
from datetime import datetime
from typing import Optional

class UserBase(BaseModel):
    email: EmailStr = Field(..., max_length=100)
    firstname: str = Field(..., max_length=50)
    lastname: str = Field(..., max_length=50)
    user_type: str = Field(..., max_length=20)

class UserCreate(UserBase):
    password: str = Field(..., min_length=8, max_length=100)

class UserInDB(UserBase):
    user_id: int
    created_at: datetime
    updated_at: datetime
    is_active: bool = True

    class Config:
        orm_mode = True

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str
    user_type: str  # Include user_type in token response

class TokenData(BaseModel):
    email: Optional[str] = None
    user_type: Optional[str] = None